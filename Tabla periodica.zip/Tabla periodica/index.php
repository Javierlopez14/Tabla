<?php

$elements=['H','He', 'Li',
            'Be','B','C','N','O','F','Ne',
            'Na', 'Mg','Al','Si','P','S',
            'Cl', 'Ar', 'K','Ca', 'Sc', 'Ti',
            'V', 'Cr', 'Mn', 'Fe', 'Co',
            'Ni', 'Cu', 'Zn', 'Ga', 'Ge',
            'As', 'Se', 'Br', 'Kr', 'Rb',
            'Sr', 'Y', 'Zr', 'Nb', 'Mo',
            'Tc', 'Ru', 'Rh', 'Pd', 'Ag',
            'Cd', 'In', 'Sn', 'Sb', 'Te',
            'I','Xe','Cs','Ba','La', 'Ce',
            'Pr','Nd','Pm','Sm','Eu', 'Gd',
            'Tb', 'Dy', 'Ho', 'Er', 'Tm',
            'Yb', 'Lu', 'Hf', 'Ta', 'W', 'Re',
            'Os', 'Ir','Pt', 'Au', 'Hg',
            'Tl','Pb', 'Bi', 'Po', 'At',
            'Rn', 'Fr', 'Ra', 'Ac', 'Th',
            'Pa', 'U', 'Np', 'Pu', 'Am','Cm',
            'Bk', 'Cf', 'Es', 'Fm', 'Md','No',
            'Lr', 'Rf', 'Db','Sg','Bh',
            'Hs', 'Mt', 'Ds', 'Rg', 'Cn',
            'Nh', 'Fl', 'Mc','Lv', 'Ts',
            'Og'


];

$number=[1,2,3,4,5,6,7,8,9,10,
        11,12,13,14,15,16,17,18,19,20,
        21,22,23,24,25,26,27,28,29,30,
        31,32,33,34,35,36,37,38,39,40,
        41,42,43,44,45,46,47,48,49,50,
        51,52,53,54,55,56,57,58,59,60,
        61,62,63,64,65,66,67,68,69,70,
        71,72,73,74,75,76,77,78,79,80,
        81,82,83,84,85,86,87,88,89,90,
        91,92,93,94,95,96,97,98,99,100,
        101,102,103,104,105,106,107,108,109,110,
        111,112,113,114,115,116,117,118  
];



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/style.css"
      rel="stylesheet" type="text/css">
    <title>Document</title>
</head>
<body>

<div id="jav">
    <div class="tabla">
        <h1 class="encabezado">TABLA PERIODICA DE LOS ELEMENTOS</h1>
        <div class="r1" style="color: white;">1</div>
        <div class="r2" style="color: white;">2</div>
        <div class="r3" style="color: white;">3</div>
        <div class="r4" style="color: white;">4</div>
        <div class="r5" style="color: white;">5</div>
        <div class="r6" style="color: white;">6</div>
        <div class="r7" style="color: white;">7</div>
        <div class="r8" style="color: white;">8</div>
        <div class="r9" style="color: white;">9</div>
        <div class="r10" style="color: white;">10</div>
        <div class="r11" style="color: white;">11</div>
        <div class="r12" style="color: white;">12</div>
        <div class="r13" style="color: white;">13</div>
        <div class="r14" style="color: white;">14</div>
        <div class="r15" style="color: white;">15</div>
        <div class="r16" style="color: white;">16</div>
        <div class="r17" style="color: white;">17</div>
        <div class="r18" style="color: white;">18</div>
        <div class="w1" style="color: white;">1</div>
        <div class="w2" style="color: white;">2</div>
        <div class="w3" style="color: white;">3</div>
        <div class="w4" style="color: white;">4</div>
        <div class="w5" style="color: white;">5</div>
        <div class="w6" style="color: white;">6</div>
        <div class="w7" style="color: white;">7</div>
        <div class="alcaline" style="color: white;">
            <p>Alcalinos</p>
        </div>
        <div class="alcaloide" style="color: white;">
            <p> Alcaloides </p>
        </div>

        <div id="lan" class="lans"></div>
        <div id="act" class="acts"></div>
        
        <div class="ele1">
            <?php
                $i=0;
                while($i<=0){
                    echo'<p>'.$number[$i].'</p>';
                    $i++;
                }
            ?>

            <?php
                $i=0;
                while($i<=0){
                    echo'<h1>'.$elements[$i].'</h1>';
                    $i++;
                }
            ?>
            
        </div>
        <div class="ele2">
            <p>
                <?php
                    echo $number [1];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[1];
                ?>
            </h1>

        </div>
        <div class="ele3">
         <p>
                <?php
                    echo $number [2];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[2];
                ?>
            </h1>
        </div>
        <div class="ele4">
         <p>
                <?php
                    echo $number [3];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[3];
                ?>
            </h1>
        </div>
        <div class="ele5">
        <p>
                <?php
                    echo $number [4];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[4];
                ?>
            </h1>
        </div>
        <div class="ele6">
        <p>
                <?php
                    echo $number [5];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[5];
                ?>
            </h1>
        </div>
        <div class="ele7">
            <p>
                <?php
                    echo $number [6];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[6];
                ?>
            </h1>
        </div>
        <div class="ele8">
         <p>
                <?php
                    echo $number [7];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[7];
                ?>
            </h1>
        </div>
        <div class="ele9">
        <p>
                <?php
                    echo $number [8];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[8];
                ?>
            </h1>
        </div>
        <div class="ele10">
        <p>
                <?php
                    echo $number [9];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[9];
                ?>
            </h1>
        </div>
        <div class="ele11">
        <p>
                <?php
                    echo $number [10];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[10];
                ?>
            </h1>
        </div>
        <div class="ele12">
        <p>
                <?php
                    echo $number [11];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[11];
                ?>
            </h1>
        </div>
        <div class="ele13">
        <p>
                <?php
                    echo $number [12];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[12];
                ?>
            </h1>
        </div>
        <div class="ele14">
        <p>
                <?php
                    echo $number [13];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[13];
                ?>
            </h1>
        </div>
        <div class="ele15">
        <p>
                <?php
                    echo $number [14];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[14];
                ?>
            </h1>
        </div>
        <div class="ele16">
        <p>
                <?php
                    echo $number [15];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[15];
                ?>
            </h1>
        </div>
        <div class="ele17">
        <p>
                <?php
                    echo $number [16];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[16];
                ?>
            </h1>
        </div>
        <div class="ele18">
        <p>
                <?php
                    echo $number [17];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[17];
                ?>
            </h1>
        </div>
        <div class="ele19">
        <p>
                <?php
                    echo $number [18];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[18];
                ?>
            </h1>
        </div>
        <div class="ele20">
        <p>
                <?php
                    echo $number [19];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[19];
                ?>
            </h1>
        </div>
        <div class="ele21">
        <p>
                <?php
                    echo $number [20];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[20];
                ?>
            </h1>
        </div>
        <div class="ele22">
        <p>
                <?php
                    echo $number [21];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[21];
                ?>
            </h1>
        </div>
        <div class="ele23">
        <p>
                <?php
                    echo $number [22];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[22];
                ?>
            </h1>
        </div>
        <div class="ele24">
        <p>
                <?php
                    echo $number [23];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[23];
                ?>
            </h1>
        </div>
        <div class="ele25">
        <p>
                <?php
                    echo $number [24];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[24];
                ?>
            </h1>
        </div>
        <div class="ele26">
        <p>
                <?php
                    echo $number [25];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[25];
                ?>
            </h1>
        </div>
        <div class="ele27">
        <p>
                <?php
                    echo $number [26];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[26];
                ?>
            </h1>
        </div>
        <div class="ele28">
        <p>
                <?php
                    echo $number [27];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[27];
                ?>
            </h1>
        </div>
        <div class="ele29">
        <p>
                <?php
                    echo $number [28];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[28];
                ?>
            </h1>
        </div>
        <div class="ele30">  
            <p>
                <?php
                    echo $number [29];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[29];
                ?>
            </h1></div>
        <div class="ele31">
        <p>
                <?php
                    echo $number [20];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[30];
                ?>
            </h1>
        </div>
        <div class="ele32">
        <p>
                <?php
                    echo $number [31];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[31];
                ?>
            </h1>
        </div>
        <div class="ele33">
        <p>
                <?php
                    echo $number [32];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[32];
                ?>
            </h1>
        </div>
        <div class="ele34">
        <p>
                <?php
                    echo $number [33];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[33];
                ?>
            </h1>
        </div>
        <div class="ele35">
        <p>
                <?php
                    echo $number [34];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[34];
                ?>
            </h1>
        </div>
        <div class="ele36">
        <p>
                <?php
                    echo $number [35];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[35];
                ?>
            </h1>
        </div>
        <div class="ele37">
        <p>
                <?php
                    echo $number [36];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[36];
                ?>
            </h1>
        </div>
        <div class="ele38">
        <p>
                <?php
                    echo $number [37];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[37];
                ?>
            </h1>
        </div>
        <div class="ele39">
        <p>
                <?php
                    echo $number [38];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[38];
                ?>
            </h1>
        </div>
        <div class="ele40">
        <p>
                <?php
                    echo $number [39];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[39];
                ?>
            </h1>
        </div>
        <div class="ele41">
        <p>
                <?php
                    echo $number [40];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[40];
                ?>
            </h1>
        </div>
        <div class="ele42">
        <p>
                <?php
                    echo $number [41];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[41];
                ?>
            </h1>
        </div>
        <div class="ele43">
        <p>
                <?php
                    echo $number [42];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[42];
                ?>
            </h1>
        </div>
        <div class="ele44">
        <p>
                <?php
                    echo $number [43];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[43];
                ?>
            </h1>
        </div>
        <div class="ele45">
        <p>
                <?php
                    echo $number [44];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[44];
                ?>
            </h1>
        </div>
        <div class="ele46">
        <p>
                <?php
                    echo $number [45];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[45];
                ?>
            </h1>
        </div>
        <div class="ele47">
        <p>
                <?php
                    echo $number [46];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[46];
                ?>
            </h1>
        </div>
        <div class="ele48">
        <p>
                <?php
                    echo $number [47];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[47];
                ?>
            </h1>
        </div>
        <div class="ele49">
        <p>
                <?php
                    echo $number [48];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[48];
                ?>
            </h1>
        </div>
        <div class="ele50">
        <p>
                <?php
                    echo $number [49];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[49];
                ?>
            </h1>
        </div>
        <div class="ele51">
        <p>
                <?php
                    echo $number [50];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[50];
                ?>
            </h1>
        </div>
        <div class="ele52">
        <p>
                <?php
                    echo $number [51];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[51];
                ?>
            </h1>
        </div>
        <div class="ele53">
        <p>
                <?php
                    echo $number [52];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[52];
                ?>
            </h1>
        </div>
        <div class="ele54">
        <p>
                <?php
                    echo $number [53];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[53];
                ?>
            </h1>
        </div>
        <div class="ele55">
        <p>
                <?php
                    echo $number [54];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[54];
                ?>
            </h1>
        </div>
        <div class="ele56">
        <p>
                <?php
                    echo $number [55];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[55];
                ?>
            </h1>
        </div>
        <div class="ele57">
        <p>
                <?php
                    echo $number [56];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[56];
                ?>
            </h1>
        </div>
        <div class="ele58"><p>
                <?php
                    echo $number [57];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[57];
                ?>
            </h1></div>
        <div class="ele59"><p>
                <?php
                    echo $number [58];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[58];
                ?>
            </h1></div>
        <div class="ele60">
        <p>
                <?php
                    echo $number [59];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[59];
                ?>
            </h1>
        </div>
        <div class="ele61">
        <p>
                <?php
                    echo $number [60];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[60];
                ?>
            </h1>
        </div>
        <div class="ele62">
        <p>
                <?php
                    echo $number [61];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[61];
                ?>
            </h1>
        </div>
        <div class="ele63">
        <p>
                <?php
                    echo $number [62];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[62];
                ?>
            </h1>
        </div>
        <div class="ele64">
        <p>
                <?php
                    echo $number [63];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[63];
                ?>
            </h1>
        </div>
        <div class="ele65">
        <p>
                <?php
                    echo $number [64];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[64];
                ?>
            </h1>
        </div>
        <div class="ele66">
        <p>
                <?php
                    echo $number [65];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[65];
                ?>
            </h1>
        </div>
        <div class="ele67">
        <p>
                <?php
                    echo $number [66];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[66];
                ?>
            </h1>
        </div>
        <div class="ele68">
        <p>
                <?php
                    echo $number [67];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[67];
                ?>
            </h1>
        </div>
        <div class="ele69">
        <p>
                <?php
                    echo $number [68];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[68];
                ?>
            </h1>
        </div>
        <div class="ele70">
        <p>
                <?php
                    echo $number [69];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[69];
                ?>
            </h1>
        </div>
        <div class="ele71">
        <p>
                <?php
                    echo $number [70];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[70];
                ?>
            </h1>
        </div>
        <div class="ele72">
        <p>
                <?php
                    echo $number [71];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[71];
                ?>
            </h1>
        </div>
        <div class="ele73">
        <p>
                <?php
                    echo $number [72];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[72];
                ?>
            </h1>
        </div>
        <div class="ele74">
        <p>
                <?php
                    echo $number [73];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[73];
                ?>
            </h1>
        </div>
        <div class="ele75">
        <p>
                <?php
                    echo $number [74];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[74];
                ?>
            </h1>
        </div>
        <div class="ele76">
        <p>
                <?php
                    echo $number [75];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[75];
                ?>
            </h1>
        </div>
        <div class="ele77">
        <p>
                <?php
                    echo $number [76];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[76];
                ?>
            </h1>
        </div>
        <div class="ele78">
        <p>
                <?php
                    echo $number [77];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[77];
                ?>
            </h1>
        </div>
        <div class="ele79"><p>
                <?php
                    echo $number [78];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[78];
                ?>
            </h1></div>
        <div class="ele80">
        <p>
                <?php
                    echo $number [79];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[79];
                ?>
            </h1>
        </div>
        <div class="ele81">
        <p>
                <?php
                    echo $number [80];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[80];
                ?>
            </h1>
        </div>
        <div class="ele82">
        <p>
                <?php
                    echo $number [81];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[81];
                ?>
            </h1>
        </div>
        <div class="ele83">
        <p>
                <?php
                    echo $number [82];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[82];
                ?>
            </h1>
        </div>
        <div class="ele84">
        <p>
                <?php
                    echo $number [83];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[83];
                ?>
            </h1>
        </div>
        <div class="ele85">
        <p>
                <?php
                    echo $number [84];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[84];
                ?>
            </h1>
        </div>
        <div class="ele86">
        <p>
                <?php
                    echo $number [85];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[85];
                ?>
            </h1>
        </div>
        <div class="ele87">
        <p>
                <?php
                    echo $number [86];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[86];
                ?>
            </h1>
        </div>
        <div class="ele88">
        <p>
                <?php
                    echo $number [87];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[87];
                ?>
            </h1>
        </div>
        <div class="ele89">
        <p>
                <?php
                    echo $number [88];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[88];
                ?>
            </h1>
        </div>
        <div class="ele90">
        <p>
                <?php
                    echo $number [89];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[89];
                ?>
            </h1>
        </div>
        <div class="ele91"> 
            <p>
                <?php
                    echo $number [90];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[90];
                ?>
            </h1></div>
        <div class="ele92">
        <p>
                <?php
                    echo $number [91];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[91];
                ?>
            </h1>
        </div>
        <div class="ele93">
        <p>
                <?php
                    echo $number [92];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[92];
                ?>
            </h1>
        </div>
        <div class="ele94">
        <p>
                <?php
                    echo $number [93];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[93];
                ?>
            </h1>
        </div>
        <div class="ele95">
        <p>
                <?php
                    echo $number [94];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[94];
                ?>
            </h1>
        </div>
        <div class="ele96">
        <p>
                <?php
                    echo $number [95];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[95];
                ?>
            </h1>
        </div>
        <div class="ele97">
        <p>
                <?php
                    echo $number [96];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[96];
                ?>
            </h1>
        </div>
        <div class="ele98">
        <p>
                <?php
                    echo $number [97];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[97];
                ?>
            </h1>
        </div>
        <div class="ele99">
        <p>
                <?php
                    echo $number [98];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[98];
                ?>
            </h1>
        </div>
        <div class="ele100">
        <p>
                <?php
                    echo $number [99];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[99];
                ?>
            </h1>
        </div>
        <div class="ele101">
        <p>
                <?php
                    echo $number [100];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[100];
                ?>
            </h1>
        </div>
        <div class="ele102">
        <p>
                <?php
                    echo $number [101];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[101];
                ?>
            </h1>
        </div>
        <div class="ele103">
        <p>
                <?php
                    echo $number [102];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[102];
                ?>
            </h1>
        </div>
        <div class="ele104">
        <p>
                <?php
                    echo $number [103];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[103];
                ?>
            </h1>
        </div>
        <div class="ele105">
        <p>
                <?php
                    echo $number [104];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[104];
                ?>
            </h1>
        </div>
        <div class="ele106">
        <p>
                <?php
                    echo $number [105];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[105];
                ?>
            </h1>
        </div>
        <div class="ele107">
        <p>
                <?php
                    echo $number [106];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[106];
                ?>
            </h1>
        </div>
        <div class="ele108">
        <p>
                <?php
                    echo $number [107];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[107];
                ?>
            </h1>
        </div>
        <div class="ele109">
        <p>
                <?php
                    echo $number [108];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[108];
                ?>
            </h1>
        </div>
        <div class="ele110">
        <p>
                <?php
                    echo $number [109];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[109];
                ?>
            </h1>
        </div>
        <div class="ele111">
        <p>
                <?php
                    echo $number [110];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[110];
                ?>
            </h1>
        </div>
        <div class="ele112">
        <p>
                <?php
                    echo $number [111];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[111];
                ?>
            </h1>
        </div>
        <div class="ele113">
        <p>
                <?php
                    echo $number [112];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[112];
                ?>
            </h1>
        </div>
        <div class="ele114">
        <p>
                <?php
                    echo $number [113];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[113];
                ?>
            </h1>
        </div>
        <div class="ele115">
            <p>
                <?php
                    echo $number [114];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[114];
                ?>
            </h1>
        </div>
        <div class="ele116">
        <p>
                <?php
                    echo $number [115];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[115];
                ?>
            </h1>
        </div>
        <div class="ele117">
        <p>
                <?php
                    echo $number [116];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[116];
                ?>
            </h1>
        </div>
        <div class="ele118">
        <p>
                <?php
                    echo $number [117];
                ?>
            </p>

            <h1>
                <?php
                    echo $elements[117];
                ?>
            </h1>
        </div>

        
    </div>
</div>

<div>
    <h2 id="alca" class="tipo">Alcalinos</h2>
    <h2 id="lino" class="tipo">Alcalinotereos</h2>
    <h2 id="mt" class="tipo">Metales de Transicion</h2>
    <h2 id="lata" class="tipo">Latanidos</h2>
    <h2 id="ant" class="tipo"> Antinidos </h2>
    <h2 id="om" class="tipo">Otros Metales</h2>
    <h2 id="met" class="tipo">Metaloide</h2>
    <h2 id="onm" class="tipo">Otros No Metales</h2>
    <h2 id="hal" class="tipo">Halogenos</h2>
    <h2 id="gn" class="tipo">Gases Nobles</h2>
</div>
    
 


  
</body>
</html>